import ShopifyService from "../../services/shopify.service";

import STORE_QUERY from "./graphql";

import { RuntimeContext } from "../../shared/interfaces/runtime-context";

class StoreService {

  async getStore(
    context: RuntimeContext
  ) {

    return ShopifyService.execute({

      api: "storefront",

      context,

      query: STORE_QUERY

    });

  }

}

export default new StoreService();