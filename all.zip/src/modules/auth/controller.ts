import { Request, Response } from "express";

import AuthService from "./service";
import { createRuntimeContext } from "../../lib/runtime-context";

class AuthController {
  async login(
    req: Request,
    res: Response
  ) {
    const context =
      createRuntimeContext(req);

    const result =
      await AuthService.login(context);

    return res
      .status(result.status || 200)
      .json(result);
  }

  async sendOtp(
    req: Request,
    res: Response
  ) {
    const context =
      createRuntimeContext(req);

    const result =
      await AuthService.sendOtp(context);

    return res
      .status(result.status || 200)
      .json(result);
  }

  async verifyOtp(
    req: Request,
    res: Response
  ) {
    const context =
      createRuntimeContext(req);

    const result =
      await AuthService.verifyOtp(context);

    return res
      .status(result.status || 200)
      .json(result);
  }

  async google(
    req: Request,
    res: Response
  ) {
    const context =
      createRuntimeContext(req);

    const result =
      await AuthService.loginWithGoogle(context);

    return res
      .status(result.status || 200)
      .json(result);
  }

  async logout(
    req: Request,
    res: Response
  ) {
    const context =
      createRuntimeContext(req);

    const result =
      await AuthService.logout(context);

    return res
      .status(result.status || 200)
      .json(result);
  }

  async me(
    req: Request,
    res: Response
  ) {
    const context =
      createRuntimeContext(req);

    const result =
      await AuthService.me(context);

    return res
      .status(result.status || 200)
      .json(result);
  }
}

export default new AuthController();